def format_nilai_uang(jumlah_uang):
    return f"{jumlah_uang:,.2f}".replace(",", ".")