kurs_data = {
    'USD' : 16875,
    'EUR' : 19995,
    'SGD' : 13360,
    'JPY' : 109
}

nama_mata_uang = {
    'USD' : "USD",
    'EUR' : "EUR",
    'SGD' : "SGD",
    'JPY' : "JPY",
    'IDR' : "Rp."
}