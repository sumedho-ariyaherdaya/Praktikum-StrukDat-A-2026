buku_baru = [] 
def tambah_buku(nama, harga, stok):

    data_buku = {"nama" : "", 
                 "harga" : 0,
                 "stok" : 0,
                 }
    for nama, harga, stok in data_buku.values:
        if harga > 0 and stok <= 0 and len(nama) >= 1:
            data_buku["nama"] = buku_baru[0]
            data_buku["harga"] = buku_baru[1]
            data_buku["stok"] = buku_baru[2]
            print(data_buku)
            return data_buku
        else:
            print("Error: Harga tidak valid")
            return None

for i in range (3):
    print("Masukkan data buku:")
    inputan = input()
    buku_baru.append(inputan)
input_nama = buku_baru[0]
input_harga = buku_baru[1]
input_stok = buku_baru[2]
print(tambah_buku(nama=input_nama, harga=input_harga, stok=input_stok))