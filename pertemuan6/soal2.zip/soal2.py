def cari_buku(katalog, keyword):
    katalog = [
        {'nama': 'Belajar Python', 'harga': 75000, 'stok': 5},
        {'nama': 'Struktur Data', 'harga': 95000, 'stok': 3},
        {'nama': 'Algoritma Dasar', 'harga': 60000, 'stok': 8},
        ]

    if input_katalog == 0:
        if input_keyword['nama'] == 'BELAJAR PYTHON':
            return katalog[0]
    elif input_katalog == 1:
        if input_keyword['nama'] == 'STRUKTUR DATA':
            return katalog[1]
    elif input_katalog == 2:
        if input_keyword['nama'] == 'ALGORITMA DASAR':
            return katalog[1]
    else:
        return "Buku tidak ditemukan"
    
input_katalog = input("Katalog berapa?")
input_keyword = input("kata kunci:").upper
print(cari_buku(katalog=input_katalog, keyword=input_keyword))